Imports System
Imports System.Text
Imports System.Collections.Generic
Imports System.ComponentModel

Imports DevExpress.ExpressApp

<ToolboxItemFilter("Xaf.Platform.Win")> _
Partial Public NotInheritable Class [$projectsuffix$WindowsFormsModule]
	Inherits ModuleBase
	Public Sub New()
		InitializeComponent()
	End Sub
End Class

