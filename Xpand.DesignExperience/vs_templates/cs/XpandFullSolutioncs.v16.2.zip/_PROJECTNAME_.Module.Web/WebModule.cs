using System;
using System.ComponentModel;

using DevExpress.ExpressApp;

namespace $projectsuffix$.Module.Web {
    [ToolboxItemFilter("Xaf.Platform.Web")]
    public sealed partial class $projectsuffix$AspNetModule : ModuleBase {
        public $projectsuffix$AspNetModule() {
            InitializeComponent();
        }
    }
}
