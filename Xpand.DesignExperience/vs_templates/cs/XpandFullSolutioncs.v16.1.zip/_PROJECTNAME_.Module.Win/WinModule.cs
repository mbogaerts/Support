using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel;

using DevExpress.ExpressApp;

namespace $projectsuffix$.Module.Win {
    [ToolboxItemFilter("Xaf.Platform.Win")]
    public sealed partial class $projectsuffix$WindowsFormsModule : ModuleBase {
        public $projectsuffix$WindowsFormsModule() {
            InitializeComponent();
        }
    }
}
